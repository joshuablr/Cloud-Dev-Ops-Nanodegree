aws2 cloudformation delete-stack \
--stack-name $1
